import StartingPageContent from '../components/starting-page/starting-page';

function HomePage() {
  return <StartingPageContent />;
}

export default HomePage;
